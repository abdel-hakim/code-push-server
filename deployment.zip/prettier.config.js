// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

module.exports = {
  printWidth: 135,
  endOfLine: "auto",
};
